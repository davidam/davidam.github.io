#include <stdio.h>

int
main (void)
{
  printf ("¡Hola ") /*falta punto y coma*/
  printf ("Mundo!\n");
  return 0;
}

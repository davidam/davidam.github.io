int
main (void)
{
  char c = "\n";  /* incorrect */
  return 0;
}

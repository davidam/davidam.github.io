#include <iostream>

int 
main ()
{
  std::cout << "¡Hola, mundo!\n";
  return 0;
}

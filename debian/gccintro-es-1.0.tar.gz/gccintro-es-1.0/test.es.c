#define TEST "¡Hola, Mundo!"
const char str[] = TEST;

#include <math.h>
#include <stdio.h>

int
main (void)
{
  double x = 2.0;
  double y = sqrt (x);
  printf ("The square root of %f is %f\n", x, y);
  return 0;
}

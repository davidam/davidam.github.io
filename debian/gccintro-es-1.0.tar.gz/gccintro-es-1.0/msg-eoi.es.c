#include <stdio.h>

int
main (void) 
{
  if (1) {
    printf ("¡Hola Mundo!\n");
    return 0;  /* no cierra llave */
}

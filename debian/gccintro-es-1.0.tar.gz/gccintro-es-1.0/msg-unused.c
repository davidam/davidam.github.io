int
foo (int k, char * p)
{
  int i, j;
  j = k;
  return j;
}

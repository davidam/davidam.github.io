struct btree * data;

int 
main (void)
{
  data->size = 0;  /* tipo incompleto */
  return 0;
}

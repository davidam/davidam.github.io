#include "buffer.h"
template class Buffer<float>;
template class Buffer<double>;
template class Buffer<int>;

#include <stdio.h>

int
main (void)
{        /* No cierra comillas */
  printf ("¡Hola Mundo!\n);
  return 0;
}

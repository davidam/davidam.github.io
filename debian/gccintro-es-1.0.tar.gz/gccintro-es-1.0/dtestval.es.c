#include <stdio.h>

int
main (void)
{
  printf ("El valor de NUM es %d\n", NUM);
  return 0;
}

#include <iostream.h>  /* old style */

int
main (void)
{
  cout << "Hello World!\n";
  return 0;
}

#include "hola.h"

int
main (void)
{
  hola ("cualquiera");  /* se cambia "mundo" */
  return 0;
}

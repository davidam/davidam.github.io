int 
main (int argc, char *argv[])
{
  int i, n = argc;
  double x[n];

  for (i = 0; i < n; i++)
    x[i] = i;

  return x[0];
}

#include <math.h>
#include <stdio.h>

int
main (void)
{
  double x = 2.0;
  double y = sqrt (x);
  printf ("La raíz cuadrada de %f es %f\n", x, y);
  return 0;
}

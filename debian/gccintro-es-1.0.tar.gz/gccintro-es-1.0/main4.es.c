#include <stdio.h>

int
main (void)
{
  printf ("hola mundo\n");
  return;
}

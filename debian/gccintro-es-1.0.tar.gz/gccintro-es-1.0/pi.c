#include <math.h>
#include <stdio.h>

int 
main (void) 
{
  printf ("the value of pi is %f\n", M_PI);
  return 0;
}

#include <math.h>
#include <stdio.h>

int 
main (void) 
{
  printf ("el valor de pi es %f\n", M_PI);
  return 0;
}

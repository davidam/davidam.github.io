void hello (const char * name);

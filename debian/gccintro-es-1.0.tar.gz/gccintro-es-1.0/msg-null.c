#include <stdlib.h>

int
main (void)
{
  int i = NULL;  /* incorrect */
  return 0;
}

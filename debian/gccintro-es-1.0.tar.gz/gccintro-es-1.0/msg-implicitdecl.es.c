int
main (void)
{
  printf ("¡Hola Mundo!\n"); /*hace falta*/
  return 0;         /*fichero de cabecera*/
}

#include <stdio.h>

int
main (void)
{
  printf ("Diez veces NUM es %d\n", 10 * (NUM));
  return 0;
}

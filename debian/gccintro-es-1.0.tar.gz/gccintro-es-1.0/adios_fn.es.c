#include <stdio.h>
#include "hola.h"

void 
bye (void)
{
  printf ("¡Adiós!\n");
}

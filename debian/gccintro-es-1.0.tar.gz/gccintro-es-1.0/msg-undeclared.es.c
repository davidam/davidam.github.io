int
main (void)
{
  int i;
  j = 0;     /* no declarado */
  return j;
}

void hola (const char * nombre);

#include <stdlib.h>

int
main (void)
{
  int i = NULL;  /* incorrecto */
  return 0;
}

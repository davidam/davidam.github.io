#include <stdio.h>

int
main (void)
{
  printf ("Dos y dos son %f\n", 4);
  return 0;
}

#include <stdio.h>

int
main (void)
{
  printf ("Hello ")     /* missing semicolon */
  printf ("World!\n");
  return 0;
}

#include "hello.h"

int
main (void)
{
  hello ("everyone");
  bye ();
  return 0;
}

#include <stdio.h>

int
main (void)
{
  const char asm[] = "6502";
  printf ("the string asm is '%s'\n", asm);
  return 0;
}

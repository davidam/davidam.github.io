#include <stdio.h>

int
main (void)
{
  const char asm[] = "6502";
  printf ("la cadena asm es '%s'\n", asm);
  return 0;
}

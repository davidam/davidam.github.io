#include <stdoi.h>  /* incorrecto */

int
main (void)
{
  printf ("¡Hola Mundo!\n");
  return 0;
}

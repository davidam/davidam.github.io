#include <iostream>

int
main (void)
{
  std::cout << 'Hello World!\n';  // wrong quotes
  return 0;
}

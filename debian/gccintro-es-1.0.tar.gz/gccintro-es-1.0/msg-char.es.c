int
main (void)
{
  char c = "\n";  /* incorrecto */
  return 0;
}

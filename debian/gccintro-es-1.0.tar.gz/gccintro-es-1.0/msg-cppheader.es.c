#include <iostream.h>  /* viejo estilo */

int
main (void)
{
  cout << "¡Hola Mundo!\n";
  return 0;
}

void hola (const char * nombre);
void adios (void);

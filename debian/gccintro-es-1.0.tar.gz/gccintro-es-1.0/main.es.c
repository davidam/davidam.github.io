#include "hola.h"

int
main (void)
{
  hola ("mundo");
  return 0;
}

#include "hola.h"

int
main (void)
{
  hola ("cualquiera");
  adios ();
  return 0;
}

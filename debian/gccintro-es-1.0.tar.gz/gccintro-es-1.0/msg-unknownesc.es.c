#include <stdio.h>

int
main (void)
{
  printf ("¡HOLA MUNDO!\N");
  return 0;
}

#include <string>
#include <iostream>

using namespace std;

int
main ()
{
  string s1 = "¡Hola,";
  string s2 = "Mundo!";
  cout << s1 + " " + s2 << '\n';
  return 0;
}

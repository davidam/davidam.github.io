#include <stdio.h>

int
main (void) 
{
  if (1) {
    printf ("Hello World!\n");
    return 0;  /* no closing brace */
}

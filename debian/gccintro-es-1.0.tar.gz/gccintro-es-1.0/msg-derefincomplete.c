struct btree * data;

int 
main (void)
{
  data->size = 0;  /* incomplete type */
  return 0;
}

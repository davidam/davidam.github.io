int
main (void)
{
  unsigned int i = 0;
  while (1) { i++; };
  return 0;
}

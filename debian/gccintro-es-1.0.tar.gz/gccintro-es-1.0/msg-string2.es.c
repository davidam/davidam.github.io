#include <stdio.h>

int
main (void)
{        /* Uso de comillas correctas */
  printf ('¡Hola Mundo!\n');
  return 0;
}
